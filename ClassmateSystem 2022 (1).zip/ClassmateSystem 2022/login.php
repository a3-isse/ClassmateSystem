<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'db.php';

    $query = $db->prepare("SELECT * FROM student WHERE email = ? LIMIT 1");

    $query->bind_param("s", $_POST['email']);
    $query->execute();
    $result = $query->get_result();
    $student = $result->fetch_assoc();

    if (!$student) {
        die('There was no user matching that account.');
    }

    if (password_verify($_POST['password'], $student['password'])) {
        session_regenerate_id(true);

        $_SESSION['student'] = $student;

        header('location:dashboard.php');
    }
}
?>
<?php
    $page_name="LOGIN";
    require("./layouts/header.php");
?>

    <section id="hero-area" class="header-area header-eight">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 col-md-12 col-12">
                    <div class="header-content row">
                        <form id="login-form" method="post" action="" class="col-md-10 col-sm-10">
                            <label for="email" name="email">Email:</label><br>
                            <input type="email" name="email" class="form-control" id="email" placeholder="Please enter your email"><br><br>
                            <label for="password">Password:</label><br>
                            <input type="password" name="password" class="form-control" id="password" placeholder="password"><br><br>
                            <input type="submit" class="btn btn-light" value="Submit" />
                        </form>
                    </div>
                </div>
                <div class="col-lg-7 col-md-12 col-12">
                    <div class="header-image">
                        <img src="assets/images/page-image.jpg" alt="#" data-xblocker="passed" style="visibility: visible;">
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php
    require("./layouts/footer.php");
?>