<?php
$page_name="Testmodules";
require_once 'db.php';
require("./layouts/header.php");
?>
<section id="hero-area" class="header-area header-eight">
    <div class="container row">
        <div class="col-sm-5">
            <?php
            //varilable used to store search term
            if(isset($_POST['query'])){
                $q = $conn->real_escape_string($_POST['query']);
            } else {
                $q = '';
            }

            $qry = "SELECT progress, comment FROM progress WHERE assessment_id= 11";
            $sql = $conn->query($qry);
            if ($sql->num_rows > 0) {
                echo "<table class='table'><tr><th>ID</th><th>Name</th></tr>";

                while ($row = $sql->fetch_array()){
                    echo "<tr><td>". $row['progress']. "</td><td>". $row['comment'] ."</td></tr>";
                }
                echo "</table>";

            }else{
                echo "Your search query doesn't match any data!";
            }
            ?>
        </div>
        <div class="page-image col-sm-7">
            <img src="images/page-image.jpg" class="page-image" alt="image place holder" srcset="">
        </div>
    </div>
</section>
<?php
require("./layouts/footer.php");
?>