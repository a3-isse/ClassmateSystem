<?php
$db = mysqli_connect('localhost', 'root', '', 'old');

if (mysqli_connect_errno()) {
    die(mysqli_connect_error());
}

session_start();

if(!isset($_SESSION['student'])) {
    header('location:login.php');
}
//create connection .php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "old"; //Name of db

 //Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);
?>