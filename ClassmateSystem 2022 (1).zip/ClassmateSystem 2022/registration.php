<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'db.php';

    $query = $db->prepare("INSERT INTO student (name, email, password) VALUES (?, ?, ?)");

    $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $name = $_POST['fname'] . ' ' . $_POST['lname'];
    $query->bind_param("sss", $name, $_POST['email'], $hashed_password);
    $query->execute();
    header('location:dashboard.php');
}
?>
<?php
$page_name="Signup";
require("./layouts/header.php");
?>

<section id="hero-area" class="header-area header-eight">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 col-md-12 col-12">
                <div class="header-content row">
                    <form id="register-form" method="post" action="" class="col-md-10 col-sm-10">
                        <label for="fname">First name:</label><br>
                        <input type="text" id="fname" name="fname" class="form-control" placeholder="John"><br>
                        <label for="lname">Last name:</label><br>
                        <input type="text" id="lname" name="lname" class="form-control" placeholder="Doe"><br><br>
                        <label for="email">Email:</label><br>
                        <input type="email" name="email" id="email" class="form-control" placeholder="email"><br><br>
                        <label for="password">Password:</label><br>
                        <input type="password" name="password" id="password" class="form-control"><br><br>
                        <input type="submit" value="Submit" class="btn btn-light" />
                    </form>
                </div>
            </div>
            <div class="col-lg-7 col-md-12 col-12">
                <div class="header-image">
                    <img src="assets/images/page-image.jpg" alt="#" data-xblocker="passed" style="visibility: visible;">
                </div>
            </div>
        </div>
    </div>
</section>

<?php
require("./layouts/footer.php");
?>