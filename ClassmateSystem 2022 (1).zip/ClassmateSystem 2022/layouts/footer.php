    <footer class="bd-footer fixed-bottom pt-3 pb-3">
        <div class="text-center">
            <div class="">
                <a href="http://blackboard.uwe.ac.uk">Link to UWE Blackboard</a>
            </div>
            <div class="">
                <a href="http://uwe.ac.uk">Academic support</a>
            </div>
        </div>
    </footer>

    </body>

    </html>