<?php
if(!isset($page_name)){
    $page_name = '';
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Classmates | <?php echo $page_name; ?></title>

    <link rel="shortcut icon" href="../assets/images/favicon.svg" type="image/svg">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
</head>

<body>
    <section class="navbar-area navbar-nine">
        <div class="container">
            <nav class="navbar navbar-expand-lg">
                <div class="container-fluid">
                    <a class="navbar-brand" href="index.php">
                        <img src="assets/images/logo1.png" alt="Logo">
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNine" aria-controls="navbarNine" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="toggler-icon"></span>
                        <span class="toggler-icon"></span>
                        <span class="toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNine">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <?php
                            if (!isset($_SESSION['student'])) {
                            ?>
                                <li class="nav-item">
                                    <a class="page-scroll <?php echo $page_name == 'LOGIN' ? 'active' : ''; ?>" href="./login.php">Login</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll <?php echo $page_name == 'Signup' ? 'active' : ''; ?>" href="./registration.php">Create Account</a>
                                </li>
                            <?php
                            } else {
                            ?>
                                <li class="nav-item">
                                    <a class="page-scroll <?php echo $page_name == 'Testmodules' ? 'active' : ''; ?>" href="./testmodules.php">Testmodules</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll <?php echo $page_name == 'Testassessment' ? 'active' : ''; ?>" href="./testassessment.php">Testassessment</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll <?php echo $page_name == 'Testprogress' ? 'active' : ''; ?>" href="./testprogress.php">Testprogress</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll <?php echo $page_name == 'Modules' ? 'active' : ''; ?>" href="./modules.php">Modules</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll <?php echo $page_name == 'Assessments' ? 'active' : ''; ?>" href="./assessments.php">Assessments</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll <?php echo $page_name == 'Progress' ? 'active' : ''; ?>" href="./progress.php">Progress</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll" href="./logout.php">Logout</a>
                                </li>
                            <?php
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </section>