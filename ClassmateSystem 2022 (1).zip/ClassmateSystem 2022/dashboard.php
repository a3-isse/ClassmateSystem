<?php
session_start();

if(!isset($_SESSION['student'])) {
    header('location:login.php');
}
?>
<?php
require("./layouts/header.php");
?>

<section id="hero-area" class="header-area header-eight">
    <div class="container">
        <div class="row align-items-center">
            <section class="col-lg-4">
                <h1>Hello <?php echo $_SESSION['student']['name']; ?></h1>
            </section>
            <br>
            <section class="col-lg-8 page-image">
                <img src="images/page-image.jpg" alt="image place holder" srcset="">
            </section>
        </div>
    </div>
</section>

<?php
require("./layouts/footer.php");
?>