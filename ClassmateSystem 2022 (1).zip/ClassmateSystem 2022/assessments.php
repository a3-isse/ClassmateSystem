<?php
$page_name = "Assessments";
require_once 'db.php';
require("./layouts/header.php");
?>

<section id="hero-area" class="header-area header-eight">
    <div class="container">
        <div class="row align-items-center">
            <section class="page-image col-lg-7">
                <img src="images/page-image.jpg" class="page-image" alt="image place holder" srcset="">
            </section>
            <section class="col-lg-5">
                <form style="padding: 0 20px;">
                    <div>
                        <h1>Assessment for <?php echo $_SESSION['student']['name']; ?></h1>
                    </div>
                    <div class="row">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="gender" id="not_stated" value="not started">
                            <label class="form-check-label" for="not_stated">Not Started</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="gender" id="started" value="started">
                            <label class="form-check-label" for="started">Started</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="gender" id="completed" value="completed">
                            <label class="form-check-label" for="completed">Completed</label>
                        </div>
                    </div>
                    <div class="row">
                        <input type="submit" class="btn btn-light" value="Submit">
                    </div>
                </form>
            </section>
        </div>
    </div>
</section>

<?php
require("./layouts/footer.php");
?>