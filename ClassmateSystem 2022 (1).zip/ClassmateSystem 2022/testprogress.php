<?php
$page_name = "Testprogress";
require_once 'db.php';
require("./layouts/header.php");


//varilable used to store search term
$q = ''; $r = ''; $s = '';
if(isset($_POST['progress']))
    $q = $conn->real_escape_string($_POST['progress']);
if(isset($_POST['comment']))
    $r =$conn->real_escape_string($_POST['comment']);
if(isset($_POST['student_id']))
    $s =$conn->real_escape_string($_POST['student_id']);

$sql = '';
if($q != '')
    $sql = "INSERT INTO progress (module_id, assessment_id, student_id, progress, comment) VALUES ('006','11','$s','$q', '$r')";//we ignore the id as this is blank
?>
<style>
    a{
        color: #fff;
    }
    a:hover{
        color: #fff;
        text-decoration: underline;
    }
</style>
<section id="hero-area" class="header-area header-eight">
    <div class="container">
        <div class="row align-items-center">
            <section class="col-lg-5">
                <?php
                if ($sql != '') {
                    $rst = $conn->query($sql);
                    if ($rst === TRUE) {
                        echo 'New record successful. <br/>  <a href="testprogress1.php"> Click here to see group progress </a>';
                    } else {
                        echo "Error" . $sql . "<br>" . $conn->error;
                    }
                }
                ?>
                <form method="post" class="form-inline col-md-8 col-sm-10"  action="testprogress.php">
                    <div class="row form-group ">
                        <input type="text" name="student_id" class="form-control" placeholder="student id" required>
                    </div>
                    <div class="row form-group ">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="progress" id="inlineRadio1" value="0">
                            <label class="form-check-label" for="inlineRadio1">Not Started</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="progress" id="inlineRadio2" value="50">
                            <label class="form-check-label" for="inlineRadio2">Started</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="progress" id="inlineRadio3" value="100">
                            <label class="form-check-label" for="inlineRadio3">Completed/label>
                        </div>
                    </div>
                    <div class="row form-group ">
                        <textarea name='comment' class="form-control"></textarea>
                    </div>
                    <div class="row form-group ">
                        <button type='submit' class="btn btn-light mt-3" name='submit'>comment</button>
                    </div>
                </form>
            </section>
            <section class="page-image col-lg-7">
                <img src="images/page-image.jpg" class="page-image" alt="image place holder" srcset="">
            </section>
        </div>
    </div>
</section>

<?php
require("./layouts/footer.php");
?>