<?php
$page_name="Testassessment";
require_once 'db.php';
require("./layouts/header.php");
?>

<section id="hero-area" class="header-area header-eight">
    <div class="container">
        <div class="row align-items-center">
            <section class="col-lg-6">
                <form method="post" action="testassessment.php">
                    <div class="input-group mb-3">
                        <input type="text" name="query" class="form-control" placeholder="Search Query..." aria-label="Search Query..." aria-describedby="button-addon2">
                        <button type="submit" name="submit" class="btn btn-dark" type="button" id="button-addon2">Find</button>
                    </div>
                </form>
                <?php
                if(isset($_POST['query'])){
                    $q = $conn->real_escape_string($_POST['query']);
                } else {
                    $q = '';
                }       
                $qry = "SELECT name, assessment_id, due_date FROM assessment WHERE `name` LIKE '%$q%'";
                $sql = $conn->query($qry);
                if ($sql->num_rows > 0) {
                
                
                echo "<table class='table'><tr><th>Assessments</th><th>Assessment ID</th><th>Due Date</th></tr>";
                
                while ($row = $sql->fetch_array()){
                echo "<tr><td>". $row['name']. "</td><td>". $row['assessment_id']. $row['due_date']. "</td><td></td></tr>";
                }
                echo "</table>";
                
                }else{
                    echo "Your search query doesn't match any data!";
                }
                ?>
            </section>
            <section class="page-image col-lg-6">
                <img src="images/page-image.jpg" class="page-image" alt="image place holder" srcset="">
            </section>
        </div>
    </div>
</section>

<?php
require("./layouts/footer.php");
?>