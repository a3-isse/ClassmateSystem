<?php
$page_name = "Home";
require_once 'db.php';
require("./layouts/header.php");
?>

    <section id="hero-area" class="header-area header-eight">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 col-md-12 col-12">
                    <div class="header-content">
                        <h1>Lorem ipsum is placeholder text</h1>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        </p>
                        <div class="button">
                            <a href="javascript:void(0)" class="btn primary-btn">Get Started</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-12 col-12">
                    <div class="header-image">
                        <img src="assets/images/page-image.jpg" alt="#" data-xblocker="passed"
                            style="visibility: visible;">
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php
require("./layouts/footer.php");
?>